*********************
training\_data module
*********************

.. rubric:: Module Summary

.. autosummary::
   :nosignatures:
   
   ~lib.training_data.ImageAugmentation
   ~lib.training_data.TrainingDataGenerator

.. rubric:: Module

.. automodule:: lib.training_data
   :members:
   :undoc-members:
   :show-inheritance:
