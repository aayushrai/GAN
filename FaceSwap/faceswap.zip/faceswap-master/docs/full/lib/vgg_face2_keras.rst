vgg\_face2\_keras module
========================

.. automodule:: lib.vgg_face2_keras
   :members:
   :undoc-members:
   :show-inheritance:
